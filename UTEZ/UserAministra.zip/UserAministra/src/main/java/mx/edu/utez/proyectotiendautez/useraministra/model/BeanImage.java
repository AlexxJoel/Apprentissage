package mx.edu.utez.proyectotiendautez.useraministra.model;

public class BeanImage {
}
